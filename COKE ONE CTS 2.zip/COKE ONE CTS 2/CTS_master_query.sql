select * from user_master
select * from url_master
select * from menu_master
select * from sub_menu_master
select * from menu_sub_menu_url_matrix
select * from url_group_master
select * from url_group_matrix
select * from User_Group_Right


--           Service Provider Master 
--             Service Provider Contract Entry 
--            Service Engg Master 
--    Service master
select * from Service_Provider_Master
select * from Technician_Master
select * from Technician_SE_Matrix
select * from Service_Master
select * from Service_Group_Master
select * from Serivce_Item_Matrix

select * from Reason_Master
select * from Spare_Group_Master
select * from Spare_Master
select * from Spare_Sub_Group_Master
select * from Spare_Master_Sub_Group_Matrix

select * from Spare_Entity_Price_Matrix

--SS-Annual SGA Plan Entry 
select * from ABP_master
select * from ABP_master_CCI
select * from ABP_master_STL_Allocation

--pm Configuration
select * from PM_Exclude
select * from Item_Type_Master

--            SS-Distributor Route Warehouse Services Matrix  
select * from Distributor_Route_Warehouse_Service_Matrix

--Master table --Sales Org structure
select * from c1_masters.dbo.site_master 
select * from c1_masters.dbo.entity_master
select * from c1_masters.dbo.Admin_Entity_Master
select * from c1_masters.dbo.region_master
select * from c1_masters.dbo.SM_MASTER
select * from c1_masters.dbo.ASM_MASTER
select * from c1_masters.dbo.SE_Master
select top 10 * from c1_masters.dbo.GCC_Master
select top 10 * from c1_masters.dbo.gcc_master_sales_area

--master tables
select * from item_master where Item_Type_ID = 1
select * from Item_Sub_Type_Master  where Item_Type_ID = 1
select * from Item_Type_Master  where Item_Type_ID = 1


select top 10 * from Equipment_Master where Manufacture_ID=2
select top 10 * from Manufacturer_Master  where Manufacturer_ID=2
select top 10 * from Manufacturer_Model_Matrix  where Manufacturer_ID=2

--Document master
select * from Document_MainCategory_Master
select * from Document_SubCategory_Master
select * from Document_Trans




-------------------------Transactions

--GRN Details
Select * from GRN_Header 
select * from GRN_Sub_Header
select * from GRN_Details

--placement 

select top 10 * from placement_trans where prq_status='X' order by 1 desc
select top 10 * from placement_doc
select top 10 * from HappyCall_Install_Trans order by 1 desc

select top 10 * from HappyCall_Pre_Install_Trans order by 1 desc

select * from Error_Messages_8067 where cts_request_type='P'

select * from entity_planning_plant_matrix



--Removal

select top 10 * from removal_trans order by 1 desc

select * from reason_master



--Transfer
select top 10 * from Transfer_trans order by 1 desc

select distinct transfer_status from Transfer_trans order by 1 desc

select top 10 * from Transfer_Doc order by 1 desc

select top 10 * from HappyCall_Install_Trans order by 1 desc

select top 10 * from HappyCall_Pre_Install_Trans where request_type='T'

--Refiurshbment

select top 10 * from Refurbishment_Trans order by 1 desc

--non optimal

select top 10 * from    [C1_CTS].[dbo].[Service_Payment] where payment_type is not null

select top 10 * from Service_Payment_Type

-- Break Down
select top 10 * from Call_Trans

select * from Complaint_Master

select * from Cause_Master

select * from Reason_Master

---Backend jobs (SP details) SFA to CTS

--SFA_SP_ValidateAssestOrderFile --Step1(common ) (SFA - to CTS)
--SFA_SP_ValidateAssestOrderFile_BD 
--SFA_SP_ValidateAssestOrderFile_Placement 
--SFA_SP_ValidateAssestOrderFile_Removal 
--SFA_SP_ValidateAssestOrderFile_Transfer 
--SFA_UpdateCTStoSFA_Status --Step 6 (Common) (CTS to SFA)

--common SP's
--SFA_SP_InsertMissingInfo 
--SFA_SP_InsertUpdateBarCode

--PM
select top 10 * from PM_Manual_Details
select top 10 * from pm_cancel
select top 10 * from pm_exclude
select top 10 * from PM_Manual_Generation_Validation
select top 10 * from PM_Calendar

select * from Item_Type_Master

Backend jobs (SP)
--PM_Generate_Call
--PM_Manual_Generate_Call

--Equipment Allocation
select top 10 * from Asset_Allocation_Equipment_Matrix

--STL Quaterly Sign off
select top 10 * from STL_Qtrly_Closing_Header
select top 10 * from STL_Qtrly_Closing_Details

select top 10 * from STL_Qtrly_Closing_Status


--Exception Approval 



--Recovery Letter 

select * from Missing_Recovery_Data
select * from Missing_Recovery_AVF

--backend job (SP)
--Job - InsertMissingRecoveryData

--Missing - AVF upload
--Recovered - Placement,Transfer,Removal


select top 10 * from Recovery_Letter_Request_Trans
select top 10 * from Recovery_Letter_Job_Control

--Stock Transfer

select * from ST_Delivery_Challan_Header
select * from ST_Delivery_Challan_Details
--master Status table
select * from ST_DeliveryChallanFlagmaster 
-- Happy Call 

--SP Billing
select top 10 * from Asset_Allocation_Monthly_Freeze

select top 10 * from Billing_Services_Monthly_Freeze

--backend job (SP)

--SP_Bill_Generation
--exec SP_Asset_Allocation_Monthly_Freeze;
--		exec sp_Billing_Services_Monthly_Freeze;